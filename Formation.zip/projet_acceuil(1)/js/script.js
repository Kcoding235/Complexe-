

        // Navbar functionality
        var menuBtn = document.querySelector('.main-navbar .menu-btn');
        var menulist = document.querySelector('.main-navbar .nav-list');
        var menuListItems = document.querySelectorAll('.nav-list li a');

        menuBtn.addEventListener('click', function() {
            menuBtn.classList.toggle('active');
            menulist.classList.toggle('active');
        });

        for (var i = 0; i < menuListItems.length; i++) {
            menuListItems[i].addEventListener('click', menuListItemClicked);
        }

        function menuListItemClicked() {
            menuBtn.classList.remove('active');
            menulist.classList.remove('active');
        }

        var homeSection = document.querySelector('.home');

        window.addEventListener('scroll', pageScrollFunction);
        window.addEventListener('load', pageScrollFunction);

        function pageScrollFunction() {
            if (window.scrollY > 120) {
                homeSection.classList.add('active');
            } else {
                homeSection.classList.remove('active');
            }
        }


// code pour scroller l'acceuil partenaire

   // Initialize Owl Carousel acceuil
   $('.partners-slider').owlCarousel({
    loop:true,
    autoplay: true,
    autoplayTimeout:3000,
    margin:10,
    nav:true,
    navText:["<i class='fa-solid fa-arrow-left'></i>",
             "<i class='fa-solid fa-arrow-right'></i>"],
    responsive:{
        0:{
            items:1
        },
        500:{
            items:2
        },
        700:{
            items:3
        },
        1000:{
            items:5
        }
    }
})


// code pour scroller les meilleurs laureat

  // testimonials
  $('.testimonials-slider').owlCarousel({
    loop:true,
    autoplay: true,
    autoplayTimeout:6000,
    margin:10,
    nav:true,
    navText:["<i class='fa-solid fa-arrow-left'></i>",
             "<i class='fa-solid fa-arrow-right'></i>"],
    responsive:{
        0:{
            items:1
        },
        768:{
            items:2
        }
       }
})

// code pour scroller lea galleries

  $('.photo-slider').owlCarousel({
    loop:true,
    autoplay: true,
    autoplayTimeout:7000,
    margin:10,
    nav:true,
    navText:["<i class='fa-solid fa-arrow-left'></i>",
             "<i class='fa-solid fa-arrow-right'></i>"],
    responsive:{
        0:{
            items:1
        },
        500:{
            items:2
        },
        700:{
            items:3
        },
        1000:{
            items:5
        }
       }
})
